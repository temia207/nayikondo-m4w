package smsmuk;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.muk.fcit.results.sms.Channel;
import org.muk.fcit.results.sms.RequestListener;
import org.muk.fcit.results.sms.SMSMessage;
import org.muk.fcit.results.sms.impl.ModemChannel;
import org.muk.fcit.results.sms.SMSServer;
import org.smslib.modem.ModemGateway;
import org.smslib.modem.SerialModemGateway;

/**
 *
 * @author kay
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numOfProcessors = 10;

        ModemGateway gateWay = new SerialModemGateway("modem.com1", "COM35", 460200, "Nokia", "6500c");

        Channel ch = new ModemChannel(gateWay);

        // SMSServer s = new SMSServer(ch, new RequestListenerImpl(), numOfProcessors);

        SMSServer s = new SMSServer(ch, new RequestListener() {

            public void processRequest(SMSMessage request) {
                request.getSmsData();

            }
        }, numOfProcessors);

        try {
            s.startServer();
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package smsmuk;

import org.muk.fcit.results.sms.ChannelException;
import org.muk.fcit.results.sms.SMSMessage;
import org.muk.fcit.results.sms.impl.ModemChannel;
import org.smslib.modem.SerialModemGateway;

/**
 *
 * @author kay
 */
public class Sample
{

    //   * File comm.jar should go under JDKDIR/jre/lib/ext/
    //   * File javax.comm.properties should go under JDKDIR/jre/lib/
    //   * Library files (i.e. win32com.dll for Win32 or the .so Linux library files) should go under JDKDIR/jre/bin/

    public static void main(String[] args) throws ChannelException
    {
        //Initialise the modem
        SerialModemGateway serialModemGateway = new SerialModemGateway("modem.com1", "COM21", 460200, "Nokia", "6500c");

        //Initialise the modem channel
        ModemChannel channel = new ModemChannel(serialModemGateway);


        //Read an sms msg from the modem
        //Line will block until SMS message arrives
        SMSMessage message = new SMSMessage("0712075579", "0712075579", "Wat wat wat", channel);

        channel.write(message, message.getRecepient());
        //Echo the messaged back
        SMSMessage read = channel.read();

        System.out.println(read.getSmsData());

        channel.close();
    }
}

package org.muk.fcit.results.sms.impl;

import org.muk.fcit.results.sms.ProcessorBuilder;
import org.muk.fcit.results.sms.QueryProcessingException;
import org.muk.fcit.results.sms.QueryProcessor;
import org.muk.fcit.results.sms.SMSMessage;
import org.muk.fcit.results.sms.RequestListener;

/**
 *
 * @author kay
 */
public class RequestListenerImpl implements RequestListener
{

    public void processRequest(SMSMessage request)
    {
        try
        {
            QueryProcessor queryProcessor = ProcessorBuilder.buildQueryProcessor(request.getSmsData());
            queryProcessor.processAndReply(request);
        } catch (QueryProcessingException ex)
        {
            ex.printStackTrace();
        }
    }
}

package org.muk.fcit.results.sms.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.muk.fcit.results.sms.Channel;
import org.muk.fcit.results.sms.ChannelException;
import org.muk.fcit.results.sms.SMSMessage;
import org.muk.fcit.results.util.MLogger;
import org.smslib.AGateway;
import org.smslib.AGateway.Protocols;
import org.smslib.GatewayException;
import org.smslib.ICallNotification;
import org.smslib.IGatewayStatusNotification;
import org.smslib.IInboundMessageNotification;
import org.smslib.IOrphanedMessageNotification;
import org.smslib.InboundMessage;
import org.smslib.InboundMessage.MessageClasses;
import org.smslib.Message;
import org.smslib.Message.MessageTypes;
import org.smslib.OutboundMessage;
import org.smslib.SMSLibException;
import org.smslib.Service;
import org.smslib.TimeoutException;
import org.smslib.modem.ModemGateway;

/**
 * 
 * @author kay
 */
public class ModemChannel implements Channel {

    private List<SMSMessage> bufferedMessages = new ArrayList<SMSMessage>();
    private final MLogger log = MLogger.getLogger();
    private Service srv = new Service();
    private final ModemGateway gateway;
    private boolean opened = false;

    public ModemChannel(ModemGateway gateway) {
        this.gateway = gateway;
    }

    public SMSMessage read() throws ChannelException {
        open();
        while (bufferedMessages.isEmpty()) {
            try {
                waitForNewMessages();
            } catch (Exception ex) {
                throw new ChannelException(ex);
            }
        }
        return bufferedMessages.remove(0);
    }

    private void waitForNewMessages() throws GatewayException, IOException, TimeoutException {
        List<InboundMessage> newMsgArrivals = new ArrayList<InboundMessage>();
        for (;;) {
            try {
                if (this.srv.readMessages(newMsgArrivals, MessageClasses.UNREAD) == 0) {
                    Thread.sleep(1000);
                } else {
                    break;
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(ModemChannel.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        bufferTheMessages(newMsgArrivals);
    }

    private void bufferTheMessages(List<InboundMessage> msgs) {
        for (InboundMessage message : msgs) {
            try {
                log.debug("Received SMS: " + message, null, message.getOriginator());
                SMSMessage req = new SMSMessage(message.getOriginator(), message.getText(), this);
                bufferedMessages.add(req);
            } catch (UnsupportedOperationException e) {
                log.info("Unssupported operation", e, ModemChannel.class.getSimpleName());
            }
        }
    }

    public void open() throws ChannelException {
        try {
            if (!opened) {
                initGateway();
                initService();
                opened = true;
            }
        } catch (Exception ex) {
            throw new ChannelException(ex);
        }
    }

    public void write(Object obj, String destination) throws ChannelException {
        try {
            log.debug("Sending Message: \n" + obj.toString(), null, "ModemChannel");
            log.debug("To: <<" + obj.toString() + ">>....", null, "ModemChannel");
            OutboundMessage msg = new OutboundMessage(destination, obj.toString());
            srv.sendMessage(msg);
            log.debug("Done!!!!", null, "ModemChannel");
        } catch (Exception ex) {
            throw new ChannelException(ex);
        }
    }

    public void close() {
        try {
            this.srv.stopService();
        } catch (Exception ex) {
            log.error(ex.getLocalizedMessage(), ex, gateway.getGatewayId());
        }
        this.opened = false;
    }

    private void initGateway() {
        gateway.setProtocol(Protocols.PDU);
        gateway.setInbound(true);
        gateway.setOutbound(true);
        gateway.setSimPin("0000");
    }

    private void initService() throws GatewayException, SMSLibException, TimeoutException, IOException, InterruptedException {
        this.srv.setInboundMessageNotification(new InboundNotification());
        this.srv.setCallNotification(new CallNotification());
        this.srv.setGatewayStatusNotification(new GatewayStatusNotification());
        this.srv.setOrphanedMessageNotification(new OrphanedMessageNotification());
        this.srv.addGateway(gateway);
        this.srv.startService();
    }

    // <editor-fold defaultstate="collapsed" desc="Notification Listeners">
    private class CallNotification implements ICallNotification {

        public void process(String gatewayId, String callerId) {
            System.out.println(">>> New call detected from Gateway: " + gatewayId + " : " + callerId);
        }
    }

    private class GatewayStatusNotification implements IGatewayStatusNotification {

        public void process(String gatewayId, AGateway.GatewayStatuses oldStatus, AGateway.GatewayStatuses newStatus) {
            System.out.println(">>> Gateway Status change for " + gatewayId + ", OLD: " + oldStatus + " -> NEW: " + newStatus);
        }
    }

    private class OrphanedMessageNotification implements IOrphanedMessageNotification {

        public boolean process(String gatewayId, InboundMessage msg) {
            System.out.println(">>> Orphaned message part detected from " + gatewayId);
            System.out.println(msg);
            // Since we are just testing, return FALSE and keep the orphaned message part.
            return false;
        }
    }

    private class InboundNotification implements IInboundMessageNotification {

        public void process(String gatewayId, Message.MessageTypes msgType, InboundMessage msg) {
            if (msgType == MessageTypes.INBOUND) {
                System.out.println(">>> New Inbound message detected from Gateway: " + gatewayId);
            } else if (msgType == MessageTypes.STATUSREPORT) {
                System.out.println(">>> New Inbound Status Report message detected from Gateway: " + gatewayId);
            }
            System.out.println(msg);
        }
    }
    // </editor-fold>
}

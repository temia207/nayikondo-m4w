/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.muk.fcit.results.sms;

/**
 *
 * @author kay
 */
public class ChannelException extends Exception {

    public ChannelException() {
        super();
    }

    public ChannelException(Throwable t) {
        super(t);
    }

    public ChannelException(String message) {
        super(message);
    }
}

package org.muk.fcit.results.util;

public class MLogger
{

    private static MLogger l = new MLogger();

    public static MLogger getLogger()
    {
        return l;
    }

    public synchronized void info(String message, Exception e, String gatewayId)
    {
        formatMessage(message, gatewayId, e);
    }

    public synchronized void warn(String message, Exception e, String gatewayId)
    {
        System.err.println(formatMessage(message, gatewayId));
    }

    public synchronized void debug(String message, Exception e, String gatewayId)
    {
        formatMessage(message, gatewayId, e);
    }

    public synchronized void error(String message, Exception e, String gatewayId)
    {
        formatMessage(message, gatewayId, e);
    }

    private String formatMessage(String message, String gatewayId)
    {
        return ((gatewayId == null) ? message : "GTW: " + gatewayId + ": " + message);
    }

    private void formatMessage(String message, String gatewayId, Exception e)
    {
       System.err.println(formatMessage(message, gatewayId));
        if (e != null) {
            e.printStackTrace();
        }
    }
}

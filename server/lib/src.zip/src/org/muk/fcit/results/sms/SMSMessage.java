package org.muk.fcit.results.sms;

import com.sun.org.apache.xpath.internal.operations.Gte;

/**
 *
 * @author kay
 */
public class SMSMessage {

    private Channel channel;
    private String sender;
    private String smsData;
    private String recepient;

    public SMSMessage(String sender, String sms, Channel srcChannel) {
        sms = sms.toLowerCase();
        this.smsData = sms;
        this.channel = srcChannel;
        this.sender = sender;
    }

    public SMSMessage(String sender, String recepient, String smsData, Channel channel) {
        this.channel = channel;
        this.sender = sender;
        this.smsData = smsData;
        this.recepient = recepient;
    }

    public String getRecepient() {
        return recepient;
    }

    public void setRecepient(String recepient) {
        this.recepient = recepient;
    }

    public String getSmsData() {
        return smsData;
    }

    public void reply(SMSMessage response) throws ChannelException {
        reply(response.getSmsData());
    }

    public void reply(String string) throws ChannelException {
        channel.write(string, sender);
    }

    public String toString(){
        if(smsData == null) return "null";
        return smsData;
    }

    public String getSender() {
        return sender;
    }

    
}

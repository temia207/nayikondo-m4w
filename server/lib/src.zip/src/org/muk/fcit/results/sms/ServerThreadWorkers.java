/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.muk.fcit.results.sms;

import java.util.ArrayList;
import java.util.List;
import org.muk.fcit.results.util.MLogger;

/**
 *
 * @author kay
 */
public class ServerThreadWorkers extends Thread {

    private RequestListener listener;
    private final static List<SMSMessage> requests = new ArrayList<SMSMessage>();

    public ServerThreadWorkers(RequestListener listener) {
        this.listener = listener;
    }

    public static void queueRequest(SMSMessage request) {
        synchronized (requests) {
            requests.add(request);
            requests.notifyAll();
        }
    }

    @Override
    public void run() {
        while (true) {
            try {
                SMSMessage request = waitForRequest();
                listener.processRequest(request);
            } catch (Throwable t) {
                MLogger.getLogger().error("CRITICAL ERROR: In worker Thread" + t, null, null);
                t.printStackTrace();
            }
        }
    }

    private SMSMessage waitForRequest() throws InterruptedException {
        synchronized (requests) {
            while (requests.isEmpty()) {
                requests.wait();
            }
        }
        return requests.remove(0);
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.muk.fcit.results.util;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.comm.CommPortIdentifier;
import org.smslib.Service;
import org.smslib.modem.SerialModemGateway;
//

/**
 *
 * @author kay
 */
public class ModemAutoDector {

    public static void main(String[] args) {
        Enumeration portIdentifiers = enumerateComPorts();

        while (portIdentifiers.hasMoreElements()) {
            final CommPortIdentifier object = (CommPortIdentifier) portIdentifiers.nextElement();


            System.out.println(object.getName() + "  Owned: " + object.isCurrentlyOwned()
                    + " Owner: " + object.getCurrentOwner() + "");
//            new Thread(new Runnable() {
//
//                public void run() {

//            Thread.currentThread().setName(object.getName() + " Thread");
//            if (!object.isCurrentlyOwned()) {
            tryConnect(object);
//            }
//                }
//            }).start();

        }




    }

    private static void tryConnect(CommPortIdentifier object) {
        Service srv = new Service();
        SerialModemGateway mdm = new SerialModemGateway("LOL", object.getName(), 9600, "", "");
        try {

            srv.addGateway(mdm);
            srv.startService();
            System.out.println("-- " + object.getName() + " - " + mdm.getManufacturer() + " " + mdm.getModel());
        } catch (Exception ex) {
            System.err.println("-- " + object.getName() + " - " + ex.getMessage());
        }
        try {
            srv.stopService();
        } catch (Exception ex) {
            Logger.getLogger(ModemAutoDector.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("--> Dectecting for port: " + object.getName() + " Ended");
    }

    public static Enumeration enumerateComPorts() {
        try //try reloading the driver
        {
            Field masterIdList_Field = CommPortIdentifier.class.getDeclaredField("masterIdList");
            masterIdList_Field.setAccessible(true);
            masterIdList_Field.set(null, null);

            String temp_string = System.getProperty("java.home") + File.separator + "lib" + File.separator + "javax.comm.properties";

            Method loadDriver_Method = CommPortIdentifier.class.getDeclaredMethod("loadDriver", new Class[]{
                        String.class
                    });

            loadDriver_Method.setAccessible(true); //unprotect it

            loadDriver_Method.invoke(null, new Object[]{
                        temp_string
                    });
        } catch (Exception e) {
            System.out.println(e); //***** add logger
        }

        return CommPortIdentifier.getPortIdentifiers();
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.muk.fcit.results.sms.processors;

import org.muk.fcit.results.sms.ChannelException;
import org.muk.fcit.results.sms.QueryProcessor;
import org.muk.fcit.results.sms.SMSMessage;
import org.muk.fcit.results.util.MLogger;

/**
 *
 * @author kay
 */
public class ErrorQueryProcessor implements QueryProcessor
{

    public void processAndReply(SMSMessage query)
    {
        try
        {
            query.reply(getResponse(query));
        } catch (ChannelException ex)
        {
          MLogger.getLogger().error("Error in replying", ex, null);
        }

    }

    public String getResponse(SMSMessage request)
    {
        return "Incorrect request please check your request";
    }
}

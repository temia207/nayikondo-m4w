/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.muk.fcit.results.sms;

/**
 *
 * @author kay
 */
public interface QueryProcessor
{
    public abstract void processAndReply(SMSMessage request) throws QueryProcessingException;

    public abstract String getResponse(SMSMessage request);
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.muk.fcit.results.sms;

/**
 *
 * @author kay
 */
public interface Channel {

    public void open() throws ChannelException;

    public SMSMessage read() throws ChannelException;

    public void write(Object obj, String destination) throws ChannelException;

    public void close();
}

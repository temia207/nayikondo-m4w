package org.muk.fcit.results.sms;

import org.muk.fcit.results.util.MLogger;

/**
 *
 * @author kay
 */
public class SMSServer implements Runnable {

    private final Channel channel;
    private Thread t = new Thread(this);
    private boolean keepRunning = true;

    /**
     * Instatiate the sms server if u use a serial modem one thread is preferable
     * @param channel input and output channel...the server uses for reading requests and replying
     * @param listener  responds to the server
     * @param numOfThreadWorkers number of thread to be executed
     */
    public SMSServer(Channel channel, RequestListener listener, int numOfThreadWorkers) {
        this.channel = channel;

        //Pool threads if u use a serial modem
        for (int i = 0; i < numOfThreadWorkers; i++) {
            new ServerThreadWorkers(listener).start();
        }
    }

    public void startServer() throws ChannelException {
        channel.open();
        t.start();
    }

    public void stopServer() {
        channel.close();
        keepRunning = false;
    }

    public void run() {
        while (keepRunning) {
            try {
                SMSMessage read = channel.read();
                ServerThreadWorkers.queueRequest(read);
            } catch (Exception ex) {
                MLogger.getLogger().error(ex.getMessage(), ex, null);
                MLogger.getLogger().error("Error experienced going to sleep and restart server", ex, null);
            }
        }
        //TODO: In case an exception is thrown keep retrying till modem is reconnected
    }
}

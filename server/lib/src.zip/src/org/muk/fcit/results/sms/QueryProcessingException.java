/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.muk.fcit.results.sms;

/**
 *
 * @author kay
 */
public class QueryProcessingException extends Exception {

    public QueryProcessingException() {
        super();
    }

    public QueryProcessingException(Throwable t) {
        super(t);
    }

    public QueryProcessingException(String message) {
        super(message);
    }
}

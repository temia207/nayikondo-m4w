/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.muk.fcit.results.sms;

import java.util.StringTokenizer;
import org.muk.fcit.results.sms.processors.ErrorQueryProcessor;

/**
 *
 * @author kay
 */
public abstract class ProcessorBuilder {

    public static QueryProcessor buildQueryProcessor(String query) {

        if (query == null) {
            throw new NullPointerException("The query cannot be null");
        }

        QueryProcessor qp = null;
        String firstToken = getFirstToken(query);
        try {
            Class<QueryProcessor> queryClass = loadClassForQuery(firstToken);
            qp = queryClass.newInstance();
        } catch (InstantiationException ex) {
            ex.printStackTrace();
        } catch (IllegalAccessException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
           // ex.printStackTrace();
        }

        if (qp == null) {
            qp = new ErrorQueryProcessor();
        }
        return qp;
    }

    private static String getFirstToken(String string) {
        StringTokenizer st = new StringTokenizer(string);
        return st.nextToken();
    }

    private static Class<QueryProcessor> loadClassForQuery(String query) throws ClassNotFoundException {

        String className = buildClassNameFromQuery(query);
        Class<QueryProcessor> theClass = (Class<QueryProcessor>) ClassLoader.getSystemClassLoader().loadClass("org.muk.fcit.results.sms.processors." + className + "QueryProcessor");

        return theClass;

    }

    private static String buildClassNameFromQuery(String query) {
        query = query.toLowerCase();
        char firstChar = query.charAt(0);
        firstChar = Character.toUpperCase(firstChar);
        query = query.substring(1);
        return firstChar + query;
    }
}
